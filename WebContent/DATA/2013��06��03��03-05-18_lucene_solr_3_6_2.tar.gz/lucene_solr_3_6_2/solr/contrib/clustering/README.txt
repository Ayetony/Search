The Clustering contrib plugin for Solr provides a generic mechanism for plugging in third party clustering implementations.
It currently provides clustering support for search results using the Carrot2 project.

See http://wiki.apache.org/solr/ClusteringComponent for how to get started.
